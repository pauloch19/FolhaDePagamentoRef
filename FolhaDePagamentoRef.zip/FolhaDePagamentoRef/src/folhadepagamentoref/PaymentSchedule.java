/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author paulc
 */
public class PaymentSchedule {
    private String frequency;
    private int day;
    private int times;
    Map<Integer, Employee> employees = new HashMap<Integer, Employee>();

    public int getTimes() {
        return times;
    }

    public void setTimes(int times) {
        this.times = times;
    }
    
    
    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public Map<Integer, Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(Map<Integer, Employee> employees) {
        this.employees = employees;
    }
    
    
    public void ShowSchedule()
    {
        System.out.println("Frequência: "+frequency);
        System.out.println("Dia: "+day);
        Set<Integer> keys = employees.keySet();
        for(int key: keys)
        {
            Employee employee = employees.get(key);
            System.out.println(employee.toString());
            System.out.println("Situação de pagamento: "+employee.getPaid());
        }
    }
    
    public void PayEmployeesHourlyInSchedule()
    {
        Set<Integer> keys = employees.keySet();
        for(int key: keys)
        {
            Employee employee = employees.get(key);
            if(!employee.getPaid().equals("pago"))
            {
                
                System.out.println("Frequência: "+frequency);
                System.out.println("Dia: "+day);
                System.out.println("#########################################################");
                System.out.println(employee.toString());
                if(employee instanceof HourlyEmployee && frequency.equals("semanal"))
                {
                    ((HourlyEmployee) employee).CalculateSalary(employee);
                     System.out.println("Salário: R%"+employee.getSalary());
                     System.out.println("Taxa do sindicato cobrada: R%"+employee.getSyndicateTax());
                     System.out.println("Taxa de serviços cobrada: R%"+employee.getServicesTax());
                     employee.setPaid("pago");
                     employee.setSalary(0);
                }
            }
            else
            {
                System.out.println("Empregado já foi pago");
            }
        }
        System.out.println("#########################################################");
    }
    
    public void PayEmployeesSalariedInSchedule()
    {
        Set<Integer> keys = employees.keySet();
        for(int key: keys)
        {
            Employee employee = employees.get(key);
            if(!employee.getPaid().equals("pago"))
            {
               
                System.out.println("Frequência: "+frequency);
                System.out.println("Dia: "+day);
                System.out.println("#########################################################");
                System.out.println(employee.toString());
                System.out.println("#########################################################");
                if(employee instanceof SalariedEmployee && frequency.equals("mensal"))
                {
                    int salary = (((SalariedEmployee)employee).getMensalSalary()-employee.getSyndicateTax())-employee.getServicesTax();
                    System.out.println("Salário: R%"+ salary);
                    System.out.println("Taxa do sindicato cobrada: R$"+employee.getSyndicateTax());
                    System.out.println("Taxa de serviços cobrada: R$"+employee.getServicesTax());
                    employee.setPaid("pago");
                }
            }
            else
            {
                System.out.println("Empregado "+employee.getName()+" já foi pago.");
            }
        }
        System.out.println("#########################################################");
    }
    
    public void PayEmployeesComissionedInSchedule()
    {
        Set<Integer> keys = employees.keySet();
        for(int key: keys)
        {
            Employee employee = employees.get(key);
            if(!employee.getPaid().equals("pago"))
            {
                System.out.println("Frequência: "+frequency);
                System.out.println("Dia: "+day);
                System.out.println("#########################################################");
                System.out.println(employee.toString());
                System.out.println("#########################################################");
                
                if(employee instanceof ComissionedEmployee && frequency.equals("bisemanal"))
                {
                    ((ComissionedEmployee)employee).CalculateTotalSalary();
                    int syndicateTax = employee.getSyndicateTax()/2;
                    int servicesTax = employee.getServicesTax()/2; 
                    int salary = (((ComissionedEmployee)employee).getTotalSalary()-syndicateTax)-servicesTax;
                    System.out.println("Salário: R%"+ salary);
                    System.out.println("Taxa do sindicato cobrada: R$"+employee.getSyndicateTax());
                    System.out.println("Taxa de serviços cobrada: R$"+employee.getServicesTax());
                    employee.setPaid("pago");
                    ((ComissionedEmployee)employee).setTotalSalary(0);
                }
            }
            else
            {
                System.out.println("Empregado "+employee.getName()+" já foi pago.");
            }
        }
        System.out.println("#########################################################");
    }
    
    
}
