/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Presentation {
    Scanner input = new Scanner(System.in);

    
    public void Presentation(Sys system, UndoRedo ur){
        int option, id=0, day=5, weeks=2, dayofweek=30;
        System.out.println("1.Adicionar empregado\n2.Remover Empregado\n3.Lançar cartão de ponto");
        System.out.println("4.Lançar resultado de venda\n5.Lançar taxa de serviço\n6.Alterar detalhes do funcionário");
        System.out.println("7.Rodar folha de pagamento\n8.Undo/Redo\n9.Agenda de Pagamento\n10.Criar nova agenda de Pagamento\n11.Sair");
        option = Treatment("Escolha uma das opções acima: ");
        input.nextLine();
        PaymentSchedule ps = new PaymentSchedule();
        ps.setDay(5);
        ps.setFrequency("semanal");
        ps.setTimes(1);
        system.paymentSchedule.add(ps);
        PaymentSchedule psM = new PaymentSchedule();
        psM.setDay(30);
        psM.setFrequency("mensal");
        system.paymentSchedule.add(psM);
        PaymentSchedule psB = new PaymentSchedule();
        psB.setDay(5);
        psB.setFrequency("bisemanal");
        psB.setTimes(2);
        system.paymentSchedule.add(psB);
        while(option!=11)
        {
            System.out.println("Hoje é dia: "+dayofweek);
            if(option==1)
            {
                System.out.println("Você escolheu a opção para adicionar um empregado.");
                system.AddEmployee(id, ur);
                System.out.println("O número de identificação do funcionário é: "+id);
                id++;
            }
            if(option==2)
            {
                System.out.println("Você escolheu a opção para remover um empregado.");
                system.RemoveEmployee(ur);
            }
            if(option==3)
            {
                System.out.println("Você escolheu a opção lançar cartão de ponto.");
                ReleaseTimeCard(system, day);
            }
            if(option==4)
            {
                System.out.println("Você escolheu a opção lançar resultado de vendas.");
                ReleaseSaleResult(system, day);
            }
            if(option==5)
            {
                System.out.println("Você escolheu a opção lançar taxa de serviço.");
                ReleaseServiceTax(system);
            }
            if(option==6)
            {
                System.out.println("Você escolheu a opção alterar detalhes do funcionário.");
                system.ChangeEmployeeDetails();
            }
            if(option==7)
            {
                System.out.println("Você escolheu a opção rodar folha de pagamento.");
                //system.IncreaseDaysWorked();
                RunReport(system, day, dayofweek, weeks);
                if(day==5)
                {
                    day=1;
                }
                else
                {
                    day++;
                }
                if(dayofweek==30)
                {
                    dayofweek=1;
                }
                else
                {
                    dayofweek++;
                }
            }
            if(option==8)
            {
                System.out.println("Você escolheu a opção Undo/Redo");
                Employee employee = ur.undo.pop();
                ur.redo.push(employee);
            }
            if(option==9)
            {
                System.out.println("Você escolheu a opção agenda de pagamento.");
                system.VerifySchedules();
            }
            if(option==10)
            {
                System.out.println("Você escolheu a opção criar nova agenda de pagamento.");
                AddNewSchedule(system);
            }
            if(dayofweek%7==0)
            {
                weeks++;
                system.ResetPayment();
            }
            System.out.println("1.Adicionar empregado\n2.Remover Empregado\n3.Lançar cartão de ponto");
            System.out.println("4.Lançar resultado de venda\n5.Lançar taxa de serviço\n6.Alterar detalhes do funcionário");
            System.out.println("7.Rodar folha de pagamento\n8.Undo/Redo\n9.Agenda de Pagamento\n10.Criar nova agenda de Pagamento\n11.Sair");
            option = Treatment("Escolha uma das opções acima: ");
            input.nextLine();
        }
    }
    
    public void AddNewSchedule(Sys system){
        System.out.print("Frequência: ");
        String freq = input.nextLine();
        int day=0, times=0;
        if(freq.equals("semanal"))
        {
            System.out.println("1.segunda\n2.terça\n3.quarta\n4.quinta\n5.sexta");
            day = Treatment("Dia: ");
            times=1;
            input.nextLine();
        }
        if(freq.equals("bisemanal"))
        {
            System.out.println("1.segunda\n2.terça\n3.quarta\n4.quinta\n5.sexta");
            day = Treatment("Dia: ");
            times=2;
            input.nextLine();
        }
        if(freq.equals("mensal"))
        {
            day = Treatment("Dia(1 a 30): ");
            times=1;
            input.nextLine();
        }
        if(system.SearchSchedule(freq, day)==true)
        {
            System.out.println("Já existe uma agenda com essa dia e frequência");
        }
        else
        {
            PaymentSchedule ps = new PaymentSchedule();
            ps.setDay(day);
            ps.setFrequency(freq);
            ps.setTimes(times);
            system.paymentSchedule.add(ps);
            System.out.println("Agenda criada com sucesso!");
        }
    }
    
    
    public void RunReport(Sys system, int day, int dayofweek, int weeks)
    {
        system.PayEmployeesHourly(day);
        system.PayEmployeesSalaried(dayofweek);
        system.PayEmployeesComissioned(weeks, day);
    }
    
    public void ReleaseTimeCard(Sys system,int day){
        int id = Treatment("Número de identificação(id): ");
        input.nextLine();
        Employee employee = system.employees.get(id);
        while(employee==null)
        {
            System.out.println("Empregado não encontrado.");
            id = Treatment("Número de identificação(id): ");
            input.nextLine();
            employee = system.employees.get(id);
        }
        System.out.println("Funcionário encontrado.");
        System.out.println("###############################################");
        System.out.println(employee.toString());
        System.out.println("###############################################");
        System.out.print("Deseja continuar: ");
        String option = input.nextLine();
        if(option.equals("sim"))
        {
            if(employee instanceof HourlyEmployee)
            {
                TimeCard timecard = new TimeCard();
                if(!((HourlyEmployee) employee).TCS.containsKey(day))
                {
                    timecard.ReleaseArrivalTime();
                    timecard.setDay(day);
                    ((HourlyEmployee) employee).TCS.put(day, timecard);
                }
                else
                {
                    timecard = ((HourlyEmployee) employee).TCS.get(day);
                    if(timecard.getArrivalTime()==0)
                    {
                        timecard.ReleaseArrivalTime();
                        System.out.println("Horário de chegada marcado.");
                    }
                    else if(timecard.getExitTime()==0)
                    {
                        timecard.ReleaseExitTime();
                        System.out.println("Horário de saída marcado.");
                    }
                    else
                    {
                        System.out.println("Você já bateu cartão de ponto hoje.");
                        System.out.println("Horário de chegada: "+timecard.getArrivalTime());
                        System.out.println("Horário de saída: "+timecard.getExitTime());
                    }
                }          
            }
            else
            {
                System.out.println("Empregado não é horista.");
            }
        }
    }
    
    public void ReleaseSaleResult(Sys system, int day){
        int id = Treatment("Número de identificação(id): ");
        input.nextLine();
        Employee employee = system.employees.get(id);
        while(employee==null)
        {
            System.out.println("Empregado não encontrado.");
            id = Treatment("Número de identificação(id): ");
            input.nextLine();
            employee = system.employees.get(id);
        }
        System.out.println("Funcionário encontrado.");
        System.out.println("###############################################");
        System.out.println(employee.toString());
        System.out.println("###############################################");
        System.out.print("Deseja continuar: ");
        String option = input.nextLine(); 
        if(option.equals("sim"))
        {
            if(employee instanceof ComissionedEmployee)
            {
                Comission comission = new Comission();
                comission.ReleaseSale();
                comission.setDay(day);
                ((ComissionedEmployee) employee).comissions.add(comission);
            }
            else
            {
                System.out.println("Empregado não é assalariado comissionado.");
            }
        }
        
    }

    public void ReleaseServiceTax(Sys system){
        int id = Treatment("Número de identificação(id): ");
        input.nextLine();
        Employee employee = system.employees.get(id);
        while(employee==null)
        {
            System.out.println("Empregado não encontrado.");
            id = Treatment("Número de identificação(id): ");
            input.nextLine();
            employee = system.employees.get(id);
        }
        System.out.println("Funcionário encontrado.");
        System.out.println("###############################################");
        System.out.println(employee.toString());
        System.out.println("###############################################");
        System.out.print("Deseja continuar: ");
        String option = input.nextLine(); 
        if(option.equals("sim"))
        {
            if(employee.getSyndicateParticipation().equals("sim"))
            {
                if(employee.getServicesTax()==0)
                {
                    int tax = Treatment("Qual valor da taxa: ");
                    employee.setServicesTax(tax);
                    input.nextLine();
                }
                else
                {
                    System.out.println("Já existe uma taxa no valor de "+employee.getServicesTax()+".");
                    System.out.println("Deseja alterar esse valor");
                    option = input.nextLine();
                    if(option.equals("sim"))
                    {
                        int tax = Treatment("Qual valor da taxa: ");
                        employee.setServicesTax(tax); 
                        input.nextLine();
                    }
                }
                
            }
            else
            {
                System.out.println("O funcionário não faz parte do sindicato, logo, nenhuma taxa de serviço poderá ser cobrada.");
            }
        }
    }
    
    public int Treatment(String message){
        boolean correctInput = false;
        int option=0;
        while(!correctInput){
            try{
                System.out.print(message);
                option = Integer.parseInt(input.next());
                correctInput= true;
            } catch(NumberFormatException e){
                System.out.println("O valor desejado é um número inteiro.");
            }
        }
        return option;
    }
}
