/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;

/**
 *
 * @author paulc
 */
public class Employee {
    private String name;
    private String adress;
    private String paid = "naopago";
    private String SyndicateParticipation;
    private int id;
    private int salary;
    private int SyndicateId;
    private int SyndicateTax =0;
    private int ServicesTax = 0;
    private int daysWorked=0;
    public Employee(String name, String adress, int id){
        this.name= name;
        this.adress= adress;
        this.id= id;
    }

    public String getPaid() {
        return paid;
    }

    public void setPaid(String paid) {
        this.paid = paid;
    }
    
    

    public int getDaysWorked() {
        return daysWorked;
    }

    public void setDaysWorked(int daysWorked) {
        this.daysWorked = daysWorked;
    }
    
    

    public int getServicesTax() {
        return ServicesTax;
    }

    public void setServicesTax(int ServicesTax) {
        this.ServicesTax = ServicesTax;
    }
    
    public int getSyndicateTax() {
        return SyndicateTax;
    }

    public void setSyndicateTax(int SyndicateTax) {
        this.SyndicateTax = SyndicateTax;
    }

    
    public String getSyndicateParticipation() {
        return SyndicateParticipation;
    }

    public void setSyndicateParticipation(String SyndicateParticipation) {
        this.SyndicateParticipation = SyndicateParticipation;
    }

    public int getSyndicateId() {
        return SyndicateId;
    }

    public void setSyndicateId(int SyndicateId) {
        this.SyndicateId = SyndicateId;
    }
    
   
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary =   salary;
    }
    
    @Override
    public String toString(){
        return "nome: "+name+"\nEndereço: "+adress+"\nNúmerdo de identificação: "+id;
    }
}
