/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;

/**
 *
 * @author paulc
 */
public class Sys {
    Map<Integer, Employee> employees = new HashMap<Integer, Employee>();
    java.util.ArrayList<PaymentSchedule> paymentSchedule = new java.util.ArrayList<>();
    Scanner input = new Scanner(System.in);
    /*  método SearchSchedule
    -esse método verifica se há uma agenda com a mesma frequência e dia que o usuário vai criar
    -se houver, ele retorna true, caso contrário, retorna false
    */
    public boolean SearchSchedule(String freq, int day)
    {
        boolean found = false;
        int i;
        PaymentSchedule ps;
        for(i=0;i<paymentSchedule.size();i++)
        {
            ps = paymentSchedule.get(i);
            if(ps.getFrequency().equals(freq) && ps.getDay()==day)
            {
                found = true;
                break;
            }
        }
        return found;
    }
    /*  método ResetPayment
    -esse método é chamado na classe Presentation, quando a quantidade de dias passados é igual a sete
    -todos os funcionários que estão com status de pagos, receberam o status de não pago
    */
    public void ResetPayment()
    {
        Set<Integer> keys = employees.keySet();
        for(int key: keys)
        {
            Employee employee = employees.get(key);
            if(employee.getPaid().equals("pago"))
            {
                employee.setPaid("naopago");
            }
        }
    }
    
    
    /* Método PayEmployeesHourly
    
    
    */
    public void PayEmployeesHourly(int day)
    {
        int i;
        PaymentSchedule ps;
        
        for(i=0;i<paymentSchedule.size();i++)
        {
            ps = paymentSchedule.get(i);
            if(ps.getFrequency().equals("semanal"))
            {
                if(day%ps.getDay()==0)
                {
                     ps.PayEmployeesHourlyInSchedule();
                } 
            }
        }   
    }
    
    public void PayEmployeesSalaried(int dayofweek)
    {
        int i;
        PaymentSchedule ps;
        for(i=0;i<paymentSchedule.size();i++)
        {
            ps = paymentSchedule.get(i);
            if(ps.getFrequency().equals("mensal"))
            {
                if(dayofweek==ps.getDay() )
                {
                    ps.PayEmployeesSalariedInSchedule();
                }
                
            }
        }   
    }
    
    public void PayEmployeesComissioned(int week, int day)
    {
        int i;
        PaymentSchedule ps;
        for(i=0;i<paymentSchedule.size();i++)
        {
            ps = paymentSchedule.get(i);
            if(ps.getFrequency().equals("bisemanal"))
            {
                if(week%ps.getTimes()==0  && day%ps.getDay()==0)
                {
                     ps.PayEmployeesComissionedInSchedule();
                }
               
            }
            
        }
        
    }
    
    public void AddEmployee(int id, Stack undo){
        int salaryPerHour, salaryMensal;
        Employee employee = null;
        System.out.print("Nome: ");
        String name = input.nextLine();
        System.out.print("Endereço: ");
        String adress = input.nextLine();
        System.out.print("Escolhe o tipo, horista, assalariado ou comissionado: ");
        String type = input.nextLine();
        if(type.equals("horista"))
        {
            System.out.println("Informe o salário por hora do empregado. Assumiremos que em 1h ele ganhará R$x");
            salaryPerHour =  Treatment("Salário por hora: ");
            input.nextLine();
            employee = new HourlyEmployee(name, adress, id, salaryPerHour);
            AddInSchedule("semanal", 5, employee);
        }
        if(type.equals("assalariado"))
        {
            System.out.println("Um empregado do tipo assalariado recebe um salário fixo por mês.");
            salaryMensal = Treatment("Salário mensal: ");
            input.nextLine();
            employee = new SalariedEmployee(name, adress, id, salaryMensal);
            AddInSchedule("mensal", 30, employee);
        }
        if(type.equals("comissionado"))
        {
            employee = new ComissionedEmployee(name, adress, id);  
            AddInSchedule("bisemanal", 5, employee);
        }
        System.out.print("O empregado faz parte do sindicato: ");
        String option = input.nextLine();
        if(option.equals("sim"))
        {
            int tax = Treatment("Qual a taxa do sindicato: ");
            input.nextLine();
            employee.setSyndicateParticipation("sim");
            employee.setSyndicateTax(tax);
            employee.setSyndicateId(id+1000);
            System.out.println("Número de identificação no sindicato: "+(id+1000));
        }
        else
        {
            employee.setSyndicateParticipation("nao");
            employee.setSyndicateTax(0);
            employee.setSyndicateId(0);
        }
        if(employee!=null)
        {
            UndoRedo ur = new UndoRedo();
            ur.setAction("add");
            ur.employee= employee;
           // ur.ps = SearchEmployeeInSchedule(id);
            undo.push(ur);
            employees.put(id, employee);
            System.out.println("Empregado adicionado com sucesso!");
        }
    }
    
    public void AddInSchedule(String freq, int day, Employee employee){
        int i; 
        PaymentSchedule ps;
        for(i=0;i<paymentSchedule.size();i++)
        {
            ps = paymentSchedule.get(i);
            if(ps.getFrequency().equals(freq) && ps.getDay()==day)
            {
                ps.employees.put(employee.getId(), employee);
            }
        } 
    }
    
    public void VerifySchedules()
    {
        int i;
        PaymentSchedule ps;
        for(i=0;i<paymentSchedule.size();i++)
        {
            System.out.println("###########################################################");
            ps = paymentSchedule.get(i);
            ps.ShowSchedule();
            System.out.println("###########################################################");
            System.out.print("Deseja adicionar um funcionário a essa agenda: ");
            String option = input.nextLine();
            if(option.equals("sim"))
            {
                int id = Treatment("Número de identificação do funcionário: ");
                input.nextLine();
                if(employees.containsKey(id))
                {
                    Employee employee = employees.get(id);
                    if(employee instanceof HourlyEmployee)
                    {
                        if(!ps.employees.containsKey(id))
                        {
                            if(ps.getFrequency().equals("semanal"))
                            {
                                RemoveEmployeeInSchedule(id);
                                ps.employees.put(id, employee);
                                System.out.println("Empregado adicionado na agenda com sucesso!");
                            }
                            else
                            {
                                System.out.print("O empregado não pode ser adicionado a essa agenda, ");
                                System.out.println("pois ele é horista e a agenda não é semanal.");
                            }
                        }
                        else
                        {
                            System.out.println("O empregado já faz parte dessa agenda.");
                        }
                    }
                    if(employee instanceof ComissionedEmployee)
                    {
                        if(!ps.employees.containsKey(id))
                        {
                            if(ps.getFrequency().equals("bisemanal"))
                            {
                                RemoveEmployeeInSchedule(id);
                                ps.employees.put(id, employee);
                                System.out.println("Empregado adicionado na agenda com sucesso!");
                            }
                            else
                            {
                                System.out.print("O empregado não pode ser adicionado a essa agenda, ");
                                System.out.println("pois ele é comissionado e a agenda não é bisemanal.");
                            }
                        }
                        else
                        {
                            System.out.println("O empregado já faz parte dessa agenda.");
                        }
                    }
                    if(employee instanceof SalariedEmployee)
                    {
                        if(!ps.employees.containsKey(id))
                        {
                            if(ps.getFrequency().equals("mensal"))
                            {
                                RemoveEmployeeInSchedule(id);
                                ps.employees.put(id, employee);
                                System.out.println("Empregado adicionado na agenda com sucesso!");
                            }
                            else
                            {
                                System.out.print("O empregado não pode ser adicionado a essa agenda, ");
                                System.out.println("pois ele é assalariado e a agenda não é mensal.");
                            }
                        }
                        else
                        {
                            System.out.println("O empregado já faz parte dessa agenda.");
                        }
                    }
                }
                else
                {
                    System.out.println("Empregado não foi encontrado no sistema.");
                }
            }
        }
        System.out.println("###########################################################");
    }
    
    public void RemoveEmployeeInSchedule(int id){
        int i;
        PaymentSchedule ps;
        for(i=0;i<paymentSchedule.size();i++)
        {
            ps = paymentSchedule.get(i);
            if(ps.employees.containsKey(id))
            {
                Employee employee = ps.employees.get(id);
                ps.employees.remove(id, employee);
            }
        }
        
    }
    
    public PaymentSchedule SearchEmployeeInSchedule(int id){
        int i;
        PaymentSchedule ps;
        PaymentSchedule found = null;
        for(i=0;i<paymentSchedule.size();i++)
        {
            ps = paymentSchedule.get(i);
            if(ps.employees.containsKey(id))
            {
                found = ps;
                break;
            }
        }
        return found;
    }
    
    public void RemoveEmployee(Stack undo){
       int id = Treatment("Id do funcionário que será removido: ");
       input.nextLine();
       Employee employee;
       employee = employees.get(id);
       while(employee==null)
       {
           System.out.println("Empregado não encontrado.");
           id = Treatment("Id do funcionário que será removido: ");
           input.nextLine();
           employee = employees.get(id);
       }
       System.out.println(employee.toString());
       System.out.print("Deseja remover o empregado acima: ");
       String option = input.nextLine();
       if(option.equals("sim"))
       {
           UndoRedo ur = new UndoRedo();
           ur.employee = employee;
           ur.setAction("rem");
           PaymentSchedule ps = SearchEmployeeInSchedule(employee.getId());
           ur.setFreq(ps.getFrequency());
           ur.setDay(ps.getDay());
           undo.push(ur);
           RemoveEmployeeInSchedule(employee.getId());
           employees.remove(id, employee);
           System.out.println("Empregado removido com sucesso!");
       }
       else
       {
           System.out.println("Empregado não será removido.");
       }
    }
    
    public void ChangeEmployeeDetails(){
        int id = Treatment("Id do funcionário: ");
        input.nextLine();
        while(employees.containsKey(id)==false)
        {
           System.out.println("Empregado não encontrado.");
           id = Treatment("Id do funcionário que será removido: ");
           input.nextLine();
        }
        Employee employee = employees.get(id);
        System.out.print("Deseja mudar o nome do funcionário: ");
        String option = input.nextLine();
        if(option.equals("sim"))
        {
            System.out.print("Nome: ");
            String name = input.nextLine();
            employee.setName(name);
        }
        System.out.print("Deseja mudar o endereço do funcionário: ");
        option = input.nextLine();
        if(option.equals("sim"))
        {
            System.out.print("Endereço: ");
            String adress = input.nextLine();
            employee.setAdress(adress);
        }
        System.out.print("Deseja mudar a participação do funcionário no sindicato: ");
        option = input.nextLine();
        if(option.equals("sim"))
        {
            if(employee.getSyndicateParticipation().equals("sim"))
            {
                System.out.print("O funcionário participa do sindicato, deseja retirar a participação: ");
                option = input.nextLine();
                if(option.equals("sim"))
                {
                    employee.setSyndicateParticipation("nao");
                    employee.setServicesTax(0);
                    employee.setSyndicateTax(0);
                }
                else
                {
                    System.out.print("Deseja mudar a taxa do sindicato: ");
                    option = input.nextLine();
                    if(option.equals("sim"))
                    {
                        int tax = Treatment("Taxa do sindicato: ");
                        employee.setSyndicateTax(tax);
                        input.nextLine();
                    }                    
                }
            }
            else
            {
                System.out.print("O funcionário não participa do sindicato, deseja que ele participe: ");
                option = input.nextLine();
                if(option.equals("sim"))
                {
                    employee.setSyndicateParticipation("sim");
                    int tax = Treatment("Taxa do sindicato: ");
                    employee.setSyndicateTax(tax);
                    input.nextLine();
                }
            }
        }
        System.out.print("Deseja mudar o tipo do funcionário: ");
        option = input.nextLine();
        if(option.equals("sim"))
        {
                String name = employee.getName();
                String adress = employee.getAdress();
                int newid = employee.getId();
                String SyndicateParticipation = employee.getSyndicateParticipation();
                int taxSyndicate = employee.getSyndicateTax();
                int taxServices = employee.getServicesTax();
                int idSyndicate = employee.getSyndicateId();
                int daysWorked = employee.getDaysWorked();
                System.out.print("comissionado ou assalariado ou horista: ");
                option = input.nextLine();
                if(option.equals("assalariado") && !(employee instanceof SalariedEmployee))
                {
                   int salary = Treatment("Salário mensal do funcionário: ");
                   Employee newEmployee = new SalariedEmployee(name, adress, newid, salary);
                   newEmployee.setSyndicateParticipation(SyndicateParticipation);
                   newEmployee.setServicesTax(taxServices);
                   newEmployee.setSyndicateTax(taxSyndicate);
                   newEmployee.setSyndicateId(idSyndicate);
                   newEmployee.setDaysWorked(daysWorked);
                   employees.remove(id, employee);
                   employees.put(id, newEmployee);
                   RemoveEmployeeInSchedule(id);
                   AddInSchedule("semanal", 5, newEmployee);
                   
                }
                else if(employee instanceof SalariedEmployee)
                {
                    System.out.println("O Empregado já é assalariado.");
                }
                else if(option.equals("comissionado") && !(employee instanceof ComissionedEmployee))
                {
                    Employee newEmployee = new ComissionedEmployee(name, adress, newid);
                    newEmployee.setSyndicateParticipation(SyndicateParticipation);
                    newEmployee.setServicesTax(taxServices);
                    newEmployee.setSyndicateTax(taxSyndicate);
                    newEmployee.setSyndicateId(idSyndicate);
                    newEmployee.setDaysWorked(daysWorked);
                    employees.remove(id, employee);
                    employees.put(id, newEmployee);
                    RemoveEmployeeInSchedule(id);
                    AddInSchedule("bisemanal", 10, newEmployee);
                }
                else if(employee instanceof ComissionedEmployee)
                {
                    System.out.println("O empregado já é comissionado.");
                }
                else if(option.equals("horista") && !(employee instanceof HourlyEmployee))
                {
                    int salaryhour = Treatment("Salário por hora: ");
                    input.nextLine();
                    Employee newEmployee = new HourlyEmployee(name, adress, newid, salaryhour);
                    newEmployee.setSyndicateParticipation(SyndicateParticipation);
                    newEmployee.setServicesTax(taxServices);
                    newEmployee.setSyndicateTax(taxSyndicate);
                    newEmployee.setSyndicateId(idSyndicate);
                    newEmployee.setDaysWorked(daysWorked);
                    employees.remove(id, employee);
                    employees.put(id, newEmployee);
                    RemoveEmployeeInSchedule(id);
                    AddInSchedule("mensal", 30, newEmployee);
                }
                else if(employee instanceof HourlyEmployee)
                {
                    System.out.println("O empregado já é horista.");
                }
    
           
           
        }
    }
    
    public int Treatment(String message){
        boolean correctInput = false;
        int option=0;
        while(!correctInput){
            try{
                System.out.print(message);
                option = Integer.parseInt(input.next());
                correctInput= true;
            } catch(NumberFormatException e){
                System.out.println("O valor desejado é um número inteiro.");
            }
        }
        return option;
    }
}
