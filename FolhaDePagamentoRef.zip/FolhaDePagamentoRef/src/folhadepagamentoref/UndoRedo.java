/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;

import java.util.Stack;

/**
 *
 * @author paulc
 */
public class UndoRedo {
    Stack<Employee> undo = new Stack<>();
    Stack<Employee> redo = new Stack<>();
    Stack<Employee> undoRemove = new Stack<>();
    Stack<Employee> redoRemove = new Stack<>();
  
    
}
