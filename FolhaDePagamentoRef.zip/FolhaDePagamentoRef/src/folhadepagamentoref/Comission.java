/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Comission {
    private int comission;
    private double percentage;
    private int totalSale;
    private int day;
    Scanner input = new Scanner(System.in);
    
    public int getComission() {
        return comission;
    }

    public void setComission(int comission) {
        this.comission = comission;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    public int getTotalSale() {
        return totalSale;
    }

    public void setTotalSale(int totalSale) {
        this.totalSale = totalSale;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
    
    public void ReleaseSale(){
        int cms = Treatment("Digite o valor da venda realizada: ");
        setComission(cms);
        System.out.print("Digite a porcentagem que será aplicado sob o valor acima: ");
        double per = input.nextDouble();
        setPercentage(per);
        int total = (int) ((per * cms)/100);
        setTotalSale(total);
    }
            
    public int Treatment(String message){
        boolean correctInput = false;
        int option=0;
        while(!correctInput){
            try{
                System.out.print(message);
                option = Integer.parseInt(input.next());
                correctInput= true;
            } catch(NumberFormatException e){
                System.out.println("O valor desejado é um número inteiro.");
            }
        }
        return option;
    }
    
    
    
}
