/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class TimeCard {
    private int arrivalTime;
    private int exitTime;
    private int totalTime;
    private int day;
    Scanner input = new Scanner(System.in);
    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
    
    public int getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getExitTime() {
        return exitTime;
    }

    public void setExitTime(int exitTime) {
        this.exitTime = exitTime;
    }

    public int getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(int totalTime) {
        this.totalTime = totalTime;
    }
    
    public void ReleaseArrivalTime()
    {
       int hour = Treatment("Digite a hora de chegada(ignore os minutos): ");
       setArrivalTime(hour);
    }
    
    public void ReleaseExitTime()
    {
       int hour = Treatment("Digite a hora de saída(ignore os minutos): ");
       setExitTime(hour);
       setTotalTime(exitTime-arrivalTime);
    }
    
    
    public int Treatment(String message){
        boolean correctInput = false;
        int option=0;
        while(!correctInput){
            try{
                System.out.print(message);
                option = Integer.parseInt(input.next());
                correctInput= true;
            } catch(NumberFormatException e){
                System.out.println("O valor desejado é um número inteiro.");
            }
        }
        return option;
    }
    
    @Override
    public String toString(){
       return "Hora de chegada: "+arrivalTime+"\nHora de saída: "+exitTime+"\nTotal de Horas trabalhadas no dia: "+totalTime+"h";//\nDia: "+getDay();
       
        
    }
}
