/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author paulc
 */
public class HourlyEmployee extends Employee{
    private int salaryPerHour;
    Map<Integer, TimeCard> TCS = new HashMap<Integer, TimeCard>();
    
    public HourlyEmployee(String name, String adress, int id, int salaryPerHour)
    {
        super(name, adress, id);
        this.salaryPerHour = salaryPerHour;
    }
    
    
    public int getSalaryPerHour() {
        return salaryPerHour;
    }

    public void setSalaryPerHour(int salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }
    
    public void CalculateSalary(Employee employee)
    {
        int i, total=0;
        TimeCard tc;
        Set<Integer> keys = TCS.keySet();
        for(int key: keys)
        {
            tc = TCS.get(key);
            if(tc.getTotalTime()>8)
            {
                total+= 8*salaryPerHour;
                total+= (tc.getTotalTime()-8)*(salaryPerHour*1.50);
            }
            else
            {
                total+= tc.getTotalTime()*salaryPerHour;      
            }
            System.out.println("#########################################################");
            System.out.println(tc.toString());
            System.out.println("Dia: "+tc.getDay());
            TCS.remove(key, tc);
        }
        total = total-(employee.getSyndicateTax()/4);
        total = total-(employee.getServicesTax()/4);
        employee.setSalary(total);
    }
}
