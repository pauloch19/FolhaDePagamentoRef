/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;

/**
 *
 * @author paulc
 */
public class ComissionedEmployee extends Employee{
    private int totalSalary=0;
    java.util.ArrayList<Comission> comissions = new java.util.ArrayList<>();
    public ComissionedEmployee(String name, String adress, int id){
        super(name, adress, id);   
    }

    public int getTotalSalary() {
        return totalSalary;
    }

    public void setTotalSalary(int totalSalary) {
        this.totalSalary = totalSalary;
    }
    
    public void CalculateTotalSalary(){
        int i, total=0;
        Comission cms;
        for(i=0;i<comissions.size();i++)
        {
            cms = comissions.get(i);
            
            System.out.println("Venda realizada no dia "+cms.getDay());
            System.out.println("Valor da venda: R$"+cms.getComission());
            System.out.println("Porcentagem que será retirada sob essa venda: "+cms.getPercentage()+"%");
            System.out.println("Valor recebido pelo funcionário: R%"+cms.getTotalSale());
            System.out.println("#########################################################");
            totalSalary+= total+ cms.getTotalSale();
            comissions.remove(i);
        } 
    }
    
    
}
