/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package folhadepagamentoref;

/**
 *
 * @author paulc
 */
public class SalariedEmployee extends Employee{
    private int mensalSalary;
    
    public SalariedEmployee(String name, String adress, int id, int mensalSalary){
        super(name, adress, id);
        this.mensalSalary = mensalSalary;
    }

    public int getMensalSalary() {
        return mensalSalary;
    }

    public void setMensalSalary(int mensalSalary) {
        this.mensalSalary = mensalSalary;
    }
    
    
    
}
